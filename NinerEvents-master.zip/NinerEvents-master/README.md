# NinerEvents
Web application for managing all events conducted on campus.
It allows user to browse events by applying filters like category, event date and venue. 
System allows user to register for an event, create new event. There is also a provision of writing feedback for past events. 
Implemented using agile methodologies.
Technologies used: Spring MVC, HTML5, CSS3, JavaScript, jQuery, Bootstrap, Ajax, JSON. 
